#
# TABLE STRUCTURE FOR: xcenter_admin
#

DROP TABLE IF EXISTS xcenter_admin;

CREATE TABLE `xcenter_admin` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `classic` varchar(2) NOT NULL default '2' COMMENT '1代表超级管理员，其它的为一般管理员',
  `flag` varchar(1) NOT NULL default '1' COMMENT '状态标示，1代表正常，2代表冻结',
  `created` varchar(20) NOT NULL,
  `salt` varchar(6) NOT NULL,
  `role_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `role_id` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO xcenter_admin (`id`, `username`, `password`, `classic`, `flag`, `created`, `salt`, `role_id`) VALUES (1, 'admin', '8715f560ad31e23d4f0d42f73c615919', '1', '1', '1271130344', '57b859', 0);
INSERT INTO xcenter_admin (`id`, `username`, `password`, `classic`, `flag`, `created`, `salt`, `role_id`) VALUES (11, 'master', '1bb8b05c93d7034bb9789d3f4699ac2c', '2', '1', '1387182572', 'c537db', 5);


#
# TABLE STRUCTURE FOR: xcenter_config
#

DROP TABLE IF EXISTS xcenter_config;

CREATE TABLE `xcenter_config` (
  `var` varchar(25) NOT NULL,
  `datavalue` text NOT NULL,
  PRIMARY KEY  (`var`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('close_site', '2');
INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('keyword', 'Xcenter');
INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('title', 'Xcenter');
INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('description', '这是一个小巧灵活方便定制的通用系统');
INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('close_reason', '系统升级中，暂时关闭，请稍候！');
INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('smtp_host', 'mail.pcasl.com');
INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('smtp_port', '25');
INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('smtp_mail', 'liuhe@pcasl.com');
INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('smtp_user', 'liuhe');
INSERT INTO xcenter_config (`var`, `datavalue`) VALUES ('smtp_psw', '456987');


#
# TABLE STRUCTURE FOR: xcenter_log
#

DROP TABLE IF EXISTS xcenter_log;

CREATE TABLE `xcenter_log` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uid` int(10) unsigned NOT NULL,
  `ip` varchar(18) NOT NULL,
  `created` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (1, 1, '127.0.0.1', '1386829748');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (2, 1, '127.0.0.1', '1386832571');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (3, 1, '127.0.0.1', '1386835158');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (4, 1, '127.0.0.1', '1386836303');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (5, 1, '127.0.0.1', '1386899758');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (6, 1, '127.0.0.1', '1386918532');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (7, 1, '127.0.0.1', '1386928912');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (8, 1, '127.0.0.1', '1386983901');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (9, 1, '127.0.0.1', '1386989303');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (10, 1, '127.0.0.1', '1387157196');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (12, 1, '127.0.0.1', '1387172151');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (13, 1, '127.0.0.1', '1387172735');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (14, 1, '127.0.0.1', '1387172750');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (15, 1, '127.0.0.1', '1387172782');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (16, 1, '127.0.0.1', '1387172812');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (17, 1, '127.0.0.1', '1387174729');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (18, 11, '127.0.0.1', '1387182597');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (19, 11, '127.0.0.1', '1387183913');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (20, 1, '127.0.0.1', '1387244534');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (21, 1, '127.0.0.1', '1387245560');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (22, 11, '127.0.0.1', '1387245585');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (23, 1, '127.0.0.1', '1387245696');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (24, 11, '127.0.0.1', '1387248653');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (25, 1, '127.0.0.1', '1387249201');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (26, 1, '127.0.0.1', '1387249228');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (27, 1, '127.0.0.1', '1387249792');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (28, 1, '127.0.0.1', '1387249805');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (29, 1, '127.0.0.1', '1387249833');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (30, 1, '127.0.0.1', '1387249858');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (31, 1, '127.0.0.1', '1387252275');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (32, 1, '127.0.0.1', '1387252292');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (33, 11, '127.0.0.1', '1387252312');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (34, 1, '127.0.0.1', '1387263175');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (35, 11, '127.0.0.1', '1387263197');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (36, 1, '127.0.0.1', '1387263309');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (37, 1, '127.0.0.1', '1387447466');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (38, 1, '127.0.0.1', '1387447682');
INSERT INTO xcenter_log (`id`, `uid`, `ip`, `created`) VALUES (39, 1, '127.0.0.1', '1387510414');


#
# TABLE STRUCTURE FOR: xcenter_menu
#

DROP TABLE IF EXISTS xcenter_menu;

CREATE TABLE `xcenter_menu` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `paixun` int(10) unsigned NOT NULL default '255',
  `is_del` varchar(1) NOT NULL default '1' COMMENT '1代表可删除，2代表不可删除',
  `flag` varchar(1) NOT NULL default '1' COMMENT '是否显示',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO xcenter_menu (`id`, `name`, `paixun`, `is_del`, `flag`) VALUES (1, '系统管理', 2, '2', '1');
INSERT INTO xcenter_menu (`id`, `name`, `paixun`, `is_del`, `flag`) VALUES (2, '数据库管理', 1, '2', '1');


#
# TABLE STRUCTURE FOR: xcenter_menu_rights
#

DROP TABLE IF EXISTS xcenter_menu_rights;

CREATE TABLE `xcenter_menu_rights` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `menu_id` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `sourceMod` varchar(100) NOT NULL COMMENT '该菜单的原始链接',
  `paixun` int(10) unsigned NOT NULL default '255',
  `flag` varchar(1) NOT NULL default '1' COMMENT '1代表显示，2代表隐藏',
  `is_del` varchar(1) NOT NULL default '1' COMMENT '1代表可删除，2代表不可删除',
  PRIMARY KEY  (`id`),
  KEY `menu` (`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (1, 1, '超级系统管理员', 'system/administrator', 10, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (2, 1, '模块管理', 'system/module', 9, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (3, 1, '菜单管理', 'system/menuGroup', 8, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (4, 1, '角色管理', 'system/role', 7, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (5, 1, '管理员列表', 'system/master', 6, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (6, 1, '系统设置', 'system/config', 5, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (7, 1, '系统日志', 'system/log', 4, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (8, 2, '数据备份', 'master/backup', 3, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (10, 2, '数据管理', 'master/manage', 2, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (20, 1, '服务器信息', 'system/phpinfo', 3, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (26, 1, '邮件设置', 'system/emailConfig', 2, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (29, 2, 'Sql执行', 'master/execSql', 1, '1', '2');
INSERT INTO xcenter_menu_rights (`id`, `menu_id`, `name`, `sourceMod`, `paixun`, `flag`, `is_del`) VALUES (30, 1, '修改密码', 'system/pswEdit', 1, '1', '2');


#
# TABLE STRUCTURE FOR: xcenter_mod
#

DROP TABLE IF EXISTS xcenter_mod;

CREATE TABLE `xcenter_mod` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO xcenter_mod (`id`, `name`) VALUES (1, '系统管理');
INSERT INTO xcenter_mod (`id`, `name`) VALUES (2, '数据库管理');


#
# TABLE STRUCTURE FOR: xcenter_mod_rights
#

DROP TABLE IF EXISTS xcenter_mod_rights;

CREATE TABLE `xcenter_mod_rights` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `modid` int(10) unsigned NOT NULL,
  `rights` int(10) unsigned NOT NULL,
  `right_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `rights` (`rights`),
  KEY `mod` (`modid`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (1, 2, 1, '数据备份');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (2, 2, 2, '数据管理');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (3, 2, 3, 'sql执行');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (4, 1, 4, '超级系统管理员');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (5, 1, 5, '新增模块组');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (6, 1, 6, '编辑模块组');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (7, 1, 7, '删除模块组');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (8, 1, 8, '新增权限');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (9, 1, 9, '编辑权限');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (10, 1, 10, '删除权限');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (11, 1, 11, '新增菜单组');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (12, 1, 12, '编辑菜单组');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (13, 1, 13, '删除菜单组');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (17, 1, 17, '新增角色');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (18, 1, 18, '编辑角色');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (19, 1, 19, '删除角色');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (20, 1, 20, '角色分派菜单');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (21, 1, 21, '角色分派权限');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (22, 1, 22, '新增管理员');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (23, 1, 23, '编辑管理员');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (24, 1, 24, '删除管理员');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (25, 1, 25, '管理员分派角色');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (26, 1, 26, '系统设置');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (27, 1, 27, '系统日志');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (28, 1, 28, '服务器信息');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (29, 1, 29, '邮件设置');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (30, 1, 30, '管理员修改密码');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (14, 1, 14, '新增菜单');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (15, 1, 15, '编辑菜单');
INSERT INTO xcenter_mod_rights (`id`, `modid`, `rights`, `right_name`) VALUES (16, 1, 16, '删除菜单');


#
# TABLE STRUCTURE FOR: xcenter_role
#

DROP TABLE IF EXISTS xcenter_role;

CREATE TABLE `xcenter_role` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(40) NOT NULL,
  `flag` varchar(2) NOT NULL default '1',
  `created` varchar(25) NOT NULL,
  `rights` text,
  `menu` text NOT NULL COMMENT '菜单id的集合',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO xcenter_role (`id`, `name`, `flag`, `created`, `rights`, `menu`) VALUES (4, '管理员', '2', '1354513599', '60,10,11,12,13,14,15,16,1,2,3,4,5,6,7,8,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,58,54,55,56,57', '');
INSERT INTO xcenter_role (`id`, `name`, `flag`, `created`, `rights`, `menu`) VALUES (5, 'master', '1', '1386918393', '37', 'a:2:{i:0;a:2:{s:4:\"name\";s:12:\"系统管理\";s:4:\"menu\";a:10:{i:0;a:7:{s:2:\"id\";s:1:\"1\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:21:\"超级系统管理员\";s:9:\"sourceMod\";s:20:\"system/administrator\";s:6:\"paixun\";s:1:\"1\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:1;a:7:{s:2:\"id\";s:1:\"2\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:12:\"模块管理\";s:9:\"sourceMod\";s:13:\"system/module\";s:6:\"paixun\";s:1:\"3\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:2;a:7:{s:2:\"id\";s:1:\"3\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:12:\"菜单管理\";s:9:\"sourceMod\";s:16:\"system/menuGroup\";s:6:\"paixun\";s:1:\"3\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:3;a:7:{s:2:\"id\";s:1:\"4\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:12:\"角色管理\";s:9:\"sourceMod\";s:11:\"system/role\";s:6:\"paixun\";s:1:\"4\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:4;a:7:{s:2:\"id\";s:1:\"5\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:15:\"管理员列表\";s:9:\"sourceMod\";s:13:\"system/master\";s:6:\"paixun\";s:1:\"5\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:5;a:7:{s:2:\"id\";s:1:\"6\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:12:\"系统设置\";s:9:\"sourceMod\";s:13:\"system/config\";s:6:\"paixun\";s:1:\"6\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:6;a:7:{s:2:\"id\";s:1:\"7\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:12:\"系统日志\";s:9:\"sourceMod\";s:10:\"system/log\";s:6:\"paixun\";s:1:\"7\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:7;a:7:{s:2:\"id\";s:2:\"20\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:15:\"服务器信息\";s:9:\"sourceMod\";s:14:\"system/phpinfo\";s:6:\"paixun\";s:1:\"8\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:8;a:7:{s:2:\"id\";s:2:\"26\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:12:\"邮件设置\";s:9:\"sourceMod\";s:18:\"system/emailConfig\";s:6:\"paixun\";s:3:\"255\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:9;a:7:{s:2:\"id\";s:2:\"30\";s:7:\"menu_id\";s:1:\"1\";s:4:\"name\";s:12:\"修改密码\";s:9:\"sourceMod\";s:14:\"system/pswEdit\";s:6:\"paixun\";s:3:\"255\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}}}i:1;a:2:{s:4:\"name\";s:15:\"数据库管理\";s:4:\"menu\";a:3:{i:0;a:7:{s:2:\"id\";s:1:\"8\";s:7:\"menu_id\";s:1:\"2\";s:4:\"name\";s:12:\"数据备份\";s:9:\"sourceMod\";s:13:\"master/backup\";s:6:\"paixun\";s:3:\"255\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:1;a:7:{s:2:\"id\";s:2:\"10\";s:7:\"menu_id\";s:1:\"2\";s:4:\"name\";s:12:\"数据管理\";s:9:\"sourceMod\";s:13:\"master/manage\";s:6:\"paixun\";s:3:\"255\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}i:2;a:7:{s:2:\"id\";s:2:\"29\";s:7:\"menu_id\";s:1:\"2\";s:4:\"name\";s:9:\"Sql执行\";s:9:\"sourceMod\";s:14:\"master/execSql\";s:6:\"paixun\";s:3:\"255\";s:4:\"flag\";s:1:\"1\";s:6:\"is_del\";s:1:\"2\";}}}}');


#
# TABLE STRUCTURE FOR: xcenter_sessions
#

DROP TABLE IF EXISTS xcenter_sessions;

CREATE TABLE `xcenter_sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `ip_address` varchar(45) NOT NULL default '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO xcenter_sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c4aae0f97c3c56bd166328eec2a59492', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36', 1387511330, 'a:7:{s:9:\"user_data\";s:0:\"\";s:8:\"username\";s:5:\"admin\";s:3:\"uid\";s:1:\"1\";s:10:\"login_flag\";s:2:\"ok\";s:7:\"classic\";s:1:\"1\";s:6:\"rights\";b:0;s:4:\"role\";s:1:\"0\";}');


